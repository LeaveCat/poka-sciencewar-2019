#!/bin/bash
#
cd /home/user
exec 2>/dev/null
timeout 60 /home/user/problem
